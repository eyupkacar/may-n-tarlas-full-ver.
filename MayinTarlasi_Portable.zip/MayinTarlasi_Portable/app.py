#!/usr/bin/env python3
"""
Mayın Tarlası Oyunu - Flask Sunucusu
Oyunu localhost'ta çalıştıran basit Flask uygulaması
"""

import os
import sys
import webbrowser
from pathlib import Path
from flask import Flask, send_from_directory

# Flask uygulaması oluştur
app = Flask(__name__, static_folder='dist/public', static_url_path='')

# Dist klasörünün yolunu belirle
DIST_DIR = Path(__file__).parent / 'dist' / 'public'

@app.route('/')
def index():
    """Ana sayfa"""
    return send_from_directory(DIST_DIR, 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    """Statik dosyaları sun"""
    file_path = DIST_DIR / path
    
    # Güvenlik: dosya dist klasöründe olmalı
    try:
        file_path.resolve().relative_to(DIST_DIR.resolve())
    except ValueError:
        return "Not found", 404
    
    if file_path.is_file():
        return send_from_directory(DIST_DIR, path)
    
    # Eğer dosya yoksa index.html döndür (SPA için)
    return send_from_directory(DIST_DIR, 'index.html')

@app.errorhandler(404)
def not_found(error):
    """404 hatası - SPA için index.html döndür"""
    return send_from_directory(DIST_DIR, 'index.html')

def main():
    """Ana fonksiyon"""
    port = 8000
    
    # Dist klasörünün var olup olmadığını kontrol et
    if not DIST_DIR.exists():
        print(f"Hata: {DIST_DIR} klasörü bulunamadı!")
        print("Lütfen önce 'npm run build' komutunu çalıştırın.")
        sys.exit(1)
    
    print("=" * 60)
    print("Mayın Tarlası Oyunu")
    print("=" * 60)
    print(f"Sunucu başlatılıyor: http://localhost:{port}")
    print("Oyunu kapatmak için Ctrl+C tuşlarına basın")
    print("=" * 60)
    
    # Tarayıcıyı aç
    try:
        webbrowser.open(f'http://localhost:{port}')
    except Exception as e:
        print(f"Tarayıcı açılamadı: {e}")
        print(f"Lütfen manuel olarak http://localhost:{port} adresini açın")
    
    # Flask sunucusunu başlat
    app.run(host='localhost', port=port, debug=False, use_reloader=False)

if __name__ == '__main__':
    main()
