@echo off
REM Mayın Tarlası Oyunu - Windows Batch Başlatıcısı
REM Bu dosya oyunu otomatik olarak başlatır

setlocal enabledelayedexpansion

REM Geçerli dizini al
set SCRIPT_DIR=%~dp0

REM Python'un kurulu olup olmadığını kontrol et
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo ============================================================
    echo HATA: Python bulunamadı!
    echo ============================================================
    echo.
    echo Mayın Tarlası oyununu çalıştırmak için Python gereklidir.
    echo.
    echo Lütfen Python'u yükleyin:
    echo https://www.python.org/downloads/
    echo.
    echo Kurulum sırasında "Add Python to PATH" seçeneğini işaretleyin!
    echo.
    pause
    exit /b 1
)

REM Flask'ın kurulu olup olmadığını kontrol et
python -c "import flask" >nul 2>&1
if errorlevel 1 (
    echo.
    echo Flask yükleniyor...
    pip install flask >nul 2>&1
)

REM Oyunu başlat
echo.
echo ============================================================
echo Mayın Tarlası Oyunu Başlatılıyor...
echo ============================================================
echo.
echo Sunucu başlatılıyor: http://localhost:8000
echo Oyunu kapatmak için bu pencereyi kapatın.
echo.

REM Python uygulamasını çalıştır
cd /d "%SCRIPT_DIR%"
python app.py

pause
