# Mayın Tarlası Oyunu - Portable Sürüm

## Hızlı Başlangıç

### Gereksinimler
- Windows 7 veya daha yeni
- Python 3.7+ ([İndir](https://www.python.org/downloads/))

### Kurulum

1. **Python Yükle**
   - https://www.python.org/downloads/ adresinden Python'u indir
   - Kurulum sırasında **"Add Python to PATH"** seçeneğini işaretle
   - Kurulumu tamamla

2. **Oyunu Çalıştır**
   - `run.bat` dosyasına çift tıkla
   - Oyun otomatik olarak tarayıcıda açılacak
   - Eğer açılmazsa: http://localhost:8000 adresini tarayıcıda aç

### Oyun Kontrolleri

- **Sol Tıkla**: Hücreyi aç
- **Sağ Tıkla**: Bayrak koy/kaldır
- **Çift Tıkla**: Etrafındaki güvenli hücreleri otomatik aç

### Zorluk Seviyeleri

- **Başlangıç**: 8x8 tahta, 10 mayın
- **Orta**: 16x16 tahta, 40 mayın
- **Uzman**: 16x30 tahta, 99 mayın

### Tema Seçimi

Sayfanın sağ üstünde "Açık" ve "Koyu" tema butonları var.

### Skor Kaydetme

Oyunu kazandığınızda skor otomatik olarak kaydedilir. En iyi 10 skor gösterilir.

## Sorun Giderme

### "Python bulunamadı" hatası
- Python'u yükle: https://www.python.org/downloads/
- Kurulum sırasında "Add Python to PATH" seçeneğini işaretle
- Bilgisayarı yeniden başlat

### Oyun açılmıyor
- `run.bat` dosyasını tekrar çalıştır
- Tarayıcıda http://localhost:8000 adresini aç
- Tarayıcıyı yenile (F5)

### "Port zaten kullanımda" hatası
- Başka bir program 8000 portunu kullanıyor
- `run.bat` dosyasını kapatıp tekrar aç

## Dosya Yapısı

```
MayinTarlasi_Portable/
├── run.bat              ← Oyunu başlatmak için çift tıkla
├── app.py               ← Flask uygulaması
├── dist/                ← Oyun dosyaları
│   └── public/
│       ├── index.html
│       ├── assets/
│       └── ...
└── README.md            ← Bu dosya
```

## Keyifli Oyunlar! 🎮

Sorularınız varsa lütfen iletişime geçin.
